//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport
import BookCore
import Chapter2

PlaygroundPage.current.liveView = Pages.instantiatePage2()
//#-end-hidden-code
//:#localized(key: "ProseLetsPlayBlock")
