//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport
import BookCore
import Chapter2

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, aPos, aNeg, bPos, bNeg, abPos, abNeg, oPos, oNeg)
//#-end-hidden-code
//:#localized(key: "ProseBlock")
//:#localized(key: "ProseLetsPlayBlock")
let blooty: Blooty = /*#-editable-code*/<#T##Blooty##Blooty#>/*#-end-editable-code*/
//#-hidden-code
PlaygroundPage.current.liveView = Pages.instantiatePage1(blooty: blooty)
//#-end-hidden-code
