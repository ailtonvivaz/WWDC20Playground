//
//  Pages.swift
//  Chapter2
//
//  Created by Ailton Vieira Pinto Filho on 14/05/20.
//

import BookCore
import PlaygroundSupport
import SwiftUI

public class Pages {
    public static func instantiateIntroCutscene() -> PlaygroundLiveViewable {
        UIHostingController(rootView: IntroRhCutsceneView())
    }

    public static func instantiateLiveViewPage1() -> PlaygroundLiveViewable {
        clearHints()
        let text = NSLocalizedString("LiveViewChooseBlootyRh", comment: "")
        return UIHostingController(rootView: LiveView(text: text))
    }

    public static func instantiatePage1(blooty: Blooty) -> PlaygroundLiveViewable {
        clearHints()
        return GameViewController(donors: Bloot.allCases, receivers: [blooty.getBloot(ignoreRh: Bloot.ignoreRh)], ignoreRh: Bloot.ignoreRh, limited: false)
    }

    public static func instantiateLiveViewPage2() -> PlaygroundLiveViewable {
        clearHints()
        let text = NSLocalizedString("LiveViewGetReadyBlooties", comment: "")
        return UIHostingController(rootView: LiveView(text: text))
    }

    public static func instantiatePage2() -> PlaygroundLiveViewable {
        clearHints()
        return GameViewController(donors: [.oPos, .bNeg, .aNeg, .aNeg, .aPos, .oNeg, .aPos, .oNeg], receivers: [.aPos, .bNeg, .abNeg, .aNeg, .oPos, .bNeg, .abPos, .oNeg], ignoreRh: Bloot.ignoreRh, limited: true)
    }

    public static func instantiateEpilogueCutscene() -> PlaygroundLiveViewable {
        UIHostingController(rootView: EpilogueCutsceneView())
    }
}
