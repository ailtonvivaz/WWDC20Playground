//
//  Bloot+Extension.swift
//  Chapter2_Sources
//
//  Created by Ailton Vieira Pinto Filho on 18/02/20.
//

import BookCore

extension Bloot {
    public static var ignoreRh: Bool = false
    public static var allCases: [Bloot] { allCases(ignoreRh: ignoreRh) }
    public static var random: Bloot { random(ignoreRh: ignoreRh) }
}
