//
//  Bloot+Extension.swift
//  Chapter1_Sources
//
//  Created by Ailton Vieira Pinto Filho on 18/02/20.
//

import BookCore

public extension Bloot {
    static var ignoreRh: Bool = true
    static var allCases: [Bloot] { allCases(ignoreRh: ignoreRh) }
    static var random: Bloot { random(ignoreRh: ignoreRh) }
}
