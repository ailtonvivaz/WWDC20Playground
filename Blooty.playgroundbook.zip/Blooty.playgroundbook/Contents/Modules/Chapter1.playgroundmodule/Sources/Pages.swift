//
//  Pages.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 14/05/20.
//

import BookCore
import PlaygroundSupport
import SwiftUI

public class Pages {
    public static func instantiateIntroCutscene() -> PlaygroundLiveViewable {
        UIHostingController(rootView: IntroCutsceneView())
    }

    public static func instantiateLiveViewPage1() -> PlaygroundLiveViewable {
        clearHints()
        let text = NSLocalizedString("LiveViewChooseBlooty", comment: "")
        return UIHostingController(rootView: LiveView(text: text))
    }

    public static func instantiatePage1(blooty: Blooty = .a) -> PlaygroundLiveViewable {
        clearHints()
        return GameViewController(donors: Bloot.allCases, receivers: [blooty.getBloot(ignoreRh: Bloot.ignoreRh)], ignoreRh: Bloot.ignoreRh, limited: false)
    }

    public static func instantiateLiveViewPage2() -> PlaygroundLiveViewable {
        clearHints()
        let text = NSLocalizedString("LiveViewGetReadyBlooties", comment: "")
        return UIHostingController(rootView: LiveView(text: text))
    }

    public static func instantiatePage2() -> PlaygroundLiveViewable {
        clearHints()
        return GameViewController(donors: [.a, .b, .o, .a, .ab], receivers: [.ab, .b, .ab, .a, .b], ignoreRh: Bloot.ignoreRh, limited: true)
    }
}
