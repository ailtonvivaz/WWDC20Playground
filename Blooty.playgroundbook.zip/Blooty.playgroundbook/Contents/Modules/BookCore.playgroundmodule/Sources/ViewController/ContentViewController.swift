//
//  ContentViewController.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 13/01/20.
//

import Foundation

import PlaygroundSupport
import UIKit

@objc(BookCore_ContentViewController)
public class ContentViewController: UIViewController {
    var bloot: Bloot?
    var ignoreRh: Bool
    var qtyLanes: Int

    // MARK: - Views

    var blootView: BlootView!
    lazy var blootBankView = BlootBankView(bloots: allBloots)
    let laneStackView = UIStackView()
    var lanesView: [LaneView] = []
    var constraints: [NSLayoutConstraint] = []

    var timersBlootStack: Timer!

    var allBloots: [Bloot] { Bloot.allCases(ignoreRh: ignoreRh) }
    var spawner: Spawner!

    public init(bloot: Bloot) {
        self.bloot = bloot
        self.ignoreRh = bloot.ignoreRh
        self.qtyLanes = 1
        super.init(nibName: nil, bundle: nil)
    }

    public init(ignoreRh: Bool, qtyLanes: Int) {
        self.ignoreRh = ignoreRh
        self.qtyLanes = qtyLanes
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not supported")
    }

    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.Color.primary
        setupLanesView()

        setupBlootBankView()

        activateConstraints()

        if let bloot = bloot {
            lanesView.first!.add(bloot: bloot)
        } else {
            spawner = Spawner(ignoreRh: ignoreRh, lanes: qtyLanes, delegate: self)
        }
    }

    func activateConstraints() {
        NSLayoutConstraint.activate(constraints)
    }

    func setupBlootView() {
        guard qtyLanes == 1 else { return }

        let laneView = lanesView[0]

        if let bloot = bloot {
            blootView = BlootView(bloot: bloot)
            view.addSubview(blootView)
            blootView.translatesAutoresizingMaskIntoConstraints = false
            constraints.append(contentsOf: [
                blootView.topAnchor.constraint(equalTo: laneView.topAnchor),
                blootView.centerXAnchor.constraint(equalTo: laneView.centerXAnchor),
                blootView.widthAnchor.constraint(equalTo: laneView.widthAnchor),
                blootView.heightAnchor.constraint(equalTo: blootView.widthAnchor),
            ])

            blootView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panTest)))
        }
    }

    func setupBlootBankView() {
        view.addSubview(blootBankView)
        blootBankView.translatesAutoresizingMaskIntoConstraints = false

        constraints.append(contentsOf: [
            blootBankView.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor),
            blootBankView.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            blootBankView.bottomAnchor.constraint(equalTo: view.layoutMarginsGuide.bottomAnchor),
        ])

        blootBankView.delegate = self
    }

    func setupLanesView() {
        laneStackView.axis = .horizontal
        laneStackView.alignment = .fill
        laneStackView.distribution = .fillEqually
        laneStackView.spacing = 20

        view.addSubview(laneStackView)
        laneStackView.translatesAutoresizingMaskIntoConstraints = false

        constraints.append(contentsOf: [
            laneStackView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor),
            laneStackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            laneStackView.bottomAnchor.constraint(equalTo: blootBankView.topAnchor),
        ])

        for _ in 0..<qtyLanes {
            addLane()
        }
    }

    func addLane() {
        let laneView = LaneView()
        laneStackView.addArrangedSubview(laneView)
        laneView.translatesAutoresizingMaskIntoConstraints = false

        constraints.append(laneView.widthAnchor.constraint(equalTo: laneView.heightAnchor, multiplier: 0.2))

        lanesView.append(laneView)
    }

    @objc func panTest(recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: view)
        if let view = recognizer.view {
            view.center = CGPoint(x: view.center.x + translation.x,
                                  y: view.center.y + translation.y)
        }
        recognizer.setTranslation(CGPoint.zero, in: view)
    }

    func applyConstraints(size: CGSize) {
        let higher = size.height > size.width

        if ignoreRh {
            blootBankView.lines = 1
        } else {
            blootBankView.lines = higher ? 2 : 1
        }
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyConstraints(size: view.frame.size)
    }

    deinit {
        spawner.cancel()
    }
}

// MARK: Spawner delegate

extension ContentViewController: SpawnerDelegate {
    func spawn(in index: Int, bloot: Bloot) {
        lanesView[index].add(bloot: bloot)
    }
}

// MARK: - Bank delegate

extension ContentViewController: BlootBankViewDelegate {
    func blootBankView(_ blootBankView: BlootBankView, scaleFor blootView: BlootView) -> CGFloat {
        return lanesView[0].frame.width / blootView.frame.width
    }

    func blootBankView(_ blootBankView: BlootBankView, onDrag blootView: BlootView) {
        for laneView in lanesView {
            laneView.emphasized = laneView.containsCenter(of: blootView)
        }
    }

    func blootBankView(_ blootBankView: BlootBankView, hasDropPlaceFor blootView: BlootView) -> Bool {
        var hasDropPlace = false
        for laneView in lanesView {
            laneView.emphasized = false
            if !hasDropPlace, laneView.containsCenter(of: blootView) {
                hasDropPlace = true
                let convertedFrame = laneView.convert(blootView.frame, from: blootView.superview!)
                laneView.receive(bloot: blootView.bloot, in: convertedFrame)
            }
        }

        return hasDropPlace
    }
}

// MARK: - Playground delegate

extension ContentViewController: PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    /*
     public func liveViewMessageConnectionOpened() {
         // Implement this method to be notified when the live view message connection is opened.
         // The connection will be opened when the process running Contents.swift starts running and listening for messages.
     }
     */

    /*
     public func liveViewMessageConnectionClosed() {
         // Implement this method to be notified when the live view message connection is closed.
         // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
         // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
     }
     */

    public func receive(_: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
    }
}
