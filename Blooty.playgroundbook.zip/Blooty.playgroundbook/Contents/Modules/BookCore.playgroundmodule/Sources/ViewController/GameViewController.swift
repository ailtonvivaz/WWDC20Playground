//
//  GameViewController.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 09/05/20.
//

import PlaygroundSupport
import UIKit

@objc(BookCore_GameViewController)
public class GameViewController: UIViewController {
    var donorBloots: [Bloot]
    var receiverBloots: [Bloot]
    var ignoreRh: Bool
    var limited: Bool

    // MARK: - Views

    var blootView: BlootView!
    var restartButton: UIButton!
    lazy var blootBankView = BlootBankView(bloots: donorBloots, ignoreRh: ignoreRh, limited: limited)

    var boardView: BoardView!

//    var constraints: [NSLayoutConstraint] = []

    var timersBlootStack: Timer!

    var allBloots: [Bloot] { Bloot.allCases(ignoreRh: ignoreRh) }
    var spawner: Spawner!

    private var portraitConstraints: [NSLayoutConstraint] = []
    private var landscapeConstraints: [NSLayoutConstraint] = []
    private var sharedConstraints: [NSLayoutConstraint] = []

    public init(donors: [Bloot], receivers: [Bloot], ignoreRh: Bool = true, limited: Bool = false) {
        self.donorBloots = donors.map { $0.with(donor: true) }
        self.receiverBloots = receivers.map { $0.with(donor: false) }
        self.ignoreRh = ignoreRh
        self.limited = limited
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not supported")
    }

    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Theme.Color.primary

        setupBoardView()
        setupBlootBankView()

        setupRestartButton()

        updateConstraints()
    }

    func setupBoardView() {
        boardView = BoardView()
        boardView.set(bloots: receiverBloots)
        boardView.delegate = self
        view.addSubview(boardView)

        boardView.translatesAutoresizingMaskIntoConstraints = false
        sharedConstraints.append(contentsOf: [
            boardView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor, constant: 20),
            boardView.bottomAnchor.constraint(equalTo: blootBankView.topAnchor, constant: -20),
            boardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])

        portraitConstraints.append(contentsOf: [
            boardView.widthAnchor.constraint(equalTo: view.layoutMarginsGuide.widthAnchor),
        ])

        landscapeConstraints.append(contentsOf: [
            boardView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.7),
        ])
    }

    func setupRestartButton() {
        let symbolConfig = UIImage.SymbolConfiguration(weight: .medium)

        let bottom: CGFloat = 76
        let frameSABottom = UIStackView()
        frameSABottom.axis = .horizontal
        frameSABottom.alignment = .center
        frameSABottom.distribution = .equalSpacing
        frameSABottom.spacing = 10

        view.addSubview(frameSABottom)
        frameSABottom.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            frameSABottom.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor),
            frameSABottom.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor),
            frameSABottom.heightAnchor.constraint(equalToConstant: bottom),
        ])

        restartButton = BarButtonView()
        restartButton.setImage(UIImage(systemName: "gobackward", withConfiguration: symbolConfig), for: .normal)
        frameSABottom.addArrangedSubview(restartButton)
        restartButton.addTarget(self, action: #selector(onClickRestart), for: .touchUpInside)
    }

    func setupBlootBankView() {
        view.addSubview(blootBankView)
        blootBankView.translatesAutoresizingMaskIntoConstraints = false

        let qtyBloots = Bloot.allCases(ignoreRh: ignoreRh).count

        sharedConstraints.append(contentsOf: [
            blootBankView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            blootBankView.bottomAnchor.constraint(equalTo: view.layoutMarginsGuide.bottomAnchor),
        ])

        landscapeConstraints.append(contentsOf: [
            blootBankView.widthAnchor.constraint(equalTo: view.layoutMarginsGuide.widthAnchor, multiplier: qtyBloots == 4 ? 0.5 : 1.0),
        ])

        portraitConstraints.append(contentsOf: [
            blootBankView.widthAnchor.constraint(equalTo: view.layoutMarginsGuide.widthAnchor),
        ])

        blootBankView.delegate = self
    }

    @objc func panTest(recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: view)
        if let view = recognizer.view {
            view.center = CGPoint(x: view.center.x + translation.x,
                                  y: view.center.y + translation.y)
        }
        recognizer.setTranslation(CGPoint.zero, in: view)
    }

    func applyConstraints(size: CGSize) {
        let higher = size.height > size.width

        if ignoreRh {
            blootBankView.lines = 1
        } else {
            blootBankView.lines = higher ? 2 : 1
        }
        updateConstraints()

        boardView.qtyPerLine = higher ? 3 : 4
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyConstraints(size: view.frame.size)
    }

    deinit {
        spawner.cancel()
    }

    public override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        updateConstraints()
    }

    func updateConstraints() {
        if !sharedConstraints[0].isActive {
            // activating shared constraints
            NSLayoutConstraint.activate(sharedConstraints)
        }
        if view.frame.width > view.frame.height {
            if portraitConstraints.count > 0 && portraitConstraints[0].isActive {
                NSLayoutConstraint.deactivate(portraitConstraints)
            }
            // activating regular constraints
            NSLayoutConstraint.activate(landscapeConstraints)
        } else {
            if landscapeConstraints.count > 0 && landscapeConstraints[0].isActive {
                NSLayoutConstraint.deactivate(landscapeConstraints)
            }
            // activating compact constraints
            NSLayoutConstraint.activate(portraitConstraints)
        }
    }

    public override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        updateConstraints()
    }

    func restartGame() {
        boardView.reset()
        blootBankView.reset()
    }

    //MARK: - Action

    @objc func onClickRestart(_ sender: UIButton) {
        let alertController = UIAlertController(title: NSLocalizedString("Restart", comment: ""), message: NSLocalizedString("RestartQuestion", comment: ""), preferredStyle: .alert)

        let okAction = UIAlertAction(title: NSLocalizedString("Yes", comment: ""), style: .destructive) { _ in self.restartGame() }
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)

        alertController.addAction(okAction)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }
}

// MARK: - Bank delegate

extension GameViewController: BlootBankViewDelegate {
    func blootBankView(_ blootBankView: BlootBankView, scaleFor blootView: BlootView) -> CGFloat {
        boardView.blootSize.width / blootView.frame.width
    }

    func blootBankView(_ blootBankView: BlootBankView, onDrag blootView: BlootView) {
        boardView.emphasize(for: blootView)
    }

    func blootBankView(_ blootBankView: BlootBankView, hasDropPlaceFor blootView: BlootView) -> Bool {
        if boardView.drop(blootView: blootView) {
            blootBankView.decrement(bloot: blootView.bloot)
            return true
        }
        return false
    }
}

// MARK: - BoardDelegate

extension GameViewController: BoardDelegate {
    func onWin() {
        let message: String
        if limited {
            message = NSLocalizedString("CongratulationsBlootiesMessage", comment: "")
        } else {
            message = NSLocalizedString("CongratulationsBlootyMessage", comment: "")
        }

        PlaygroundPage.current.assessmentStatus = .pass(message: message)
    }

    func onLoss() {
        var hint = NSLocalizedString("Try Again and keep that in mind: ", comment: "")
        hint += NSLocalizedString("A Blooty", comment: "")
        hint += " **\(NSLocalizedString("can't", comment: ""))** "
        hint += NSLocalizedString("beRecharged", comment: "")

        var solution: String?
        if !limited {
            let myBloot = receiverBloots[0]
            solution = NSLocalizedString("The possible solutions are: ", comment: "")
            let types: [String] = Bloot.allCases(ignoreRh: ignoreRh).filter { $0.isDonor(for: myBloot) }.map { $0.name }
            solution! += types.joined(separator: ", ")
        }

        PlaygroundPage.current.assessmentStatus = .fail(hints: [hint], solution: solution)

        UIView.animate(withDuration: 0.5, animations: {
            self.restartButton.transform = .init(scaleX: 1.75, y: 1.75)
        }) { _ in
            UIView.animate(withDuration: 0.5, animations: {
                self.restartButton.transform = .identity
            }) { _ in
            }
        }
    }
}

// MARK: - Playground delegate

extension GameViewController: PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    /*
     public func liveViewMessageConnectionOpened() {
         // Implement this method to be notified when the live view message connection is opened.
         // The connection will be opened when the process running Contents.swift starts running and listening for messages.
     }
     */

    /*
     public func liveViewMessageConnectionClosed() {
         // Implement this method to be notified when the live view message connection is closed.
         // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
         // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
     }
     */

    public func receive(_: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
    }
}
