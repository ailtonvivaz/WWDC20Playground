//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import PlaygroundSupport
import SwiftUI
import UIKit

public func clearHints() {
    switch PlaygroundPage.current.assessmentStatus {
    case .fail(hints: _, solution: _):
        PlaygroundPage.current.assessmentStatus = .fail(hints: [], solution: nil)
    default:
        break
    }
}

public func instantiateContentView() -> PlaygroundLiveViewable {
    return GameViewController(donors: [.a, .b, .o, .a, .ab], receivers: [.ab, .b, .ab, .a, .b], ignoreRh: true)
    let ignoreRh = true
    let qty = 5
    return GameViewController(donors: (0..<qty).map { _ in Bloot.random(ignoreRh: ignoreRh) }, receivers: (0..<qty).map { _ in Bloot.random(ignoreRh: ignoreRh) }, ignoreRh: true)
}
