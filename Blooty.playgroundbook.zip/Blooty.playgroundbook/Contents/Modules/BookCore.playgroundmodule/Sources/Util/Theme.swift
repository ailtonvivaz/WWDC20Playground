//
//  Theme.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 18/01/20.
//

import UIKit

public class Theme {
    public class Color {
        static let primary = UIColor(rgb: 0xFB2657)
        static let secondary = UIColor(rgb: 0xFBFBF9)
        static let background = UIColor(rgb: 0x201F1D)
    }
}
