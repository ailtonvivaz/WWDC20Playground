//
//  Constants.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 18/01/20.
//

import UIKit

public extension UIImage {
    static let cellBlood = UIImage(named: "cell_blood")!
    static let aBlood = UIImage(named: "a_blood")!
    static let bBlood = UIImage(named: "b_blood")!
    static let rhBlood = UIImage(named: "rh_blood")!
    
    static let cellAnti = UIImage(named: "cell_anti")!
    static let aAnti = UIImage(named: "a_anti")!
    static let bAnti = UIImage(named: "b_anti")!
    static let rhAnti = UIImage(named: "rh_anti")!

    static let line = UIImage(named: "line")!
    static let heart = UIImage(named: "heart")!
}
