//
//  Operators.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 25/01/20.
//

import Foundation

precedencegroup PowerPrecedence { higherThan: MultiplicationPrecedence }
infix operator ^^: PowerPrecedence
func ^^ (radix: Int, power: Int) -> Int {
    return Int(pow(Double(radix), Double(power)))
}
