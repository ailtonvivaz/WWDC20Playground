//
//  WeightedList.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 06/02/20.
//

import Foundation

struct WeightedList<T> {
    var items: [WeightedItem<T>]
    
    init(_ items: [WeightedItem<T>]) {
        self.items = items
    }
    
    var randomElement: T {
        let sum = items.map({ $0.weight }).reduce(0, +)
        let rnd = Double.random(in: 0 ... sum)
        var accum = 0.0
        for item in items {
            accum += item.weight
            if rnd < accum { return item.item }
        }
        return items.last!.item
    }
}

struct WeightedItem<T> {
    var item: T
    var weight: Double
}
