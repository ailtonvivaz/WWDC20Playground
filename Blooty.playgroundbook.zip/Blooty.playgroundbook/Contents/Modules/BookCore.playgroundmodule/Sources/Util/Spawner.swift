//
//  BlootSpawner.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 06/02/20.
//

import Foundation

protocol SpawnerDelegate {
    func spawn(in index: Int, bloot: Bloot)
}

class Spawner {
    var ignoreRh: Bool
    var lanes: Int

    var delegate: SpawnerDelegate

    var timers: [Timer] = []

    init(ignoreRh: Bool, lanes: Int, delegate: SpawnerDelegate) {
        self.ignoreRh = ignoreRh
        self.lanes = lanes
        self.delegate = delegate

        self.timers = (0..<lanes).map { i in
            Timer.scheduledTimer(withTimeInterval: .random(in: 0...2), repeats: false, block: { _ in self.spawn(in: i) })
        }
    }

    private func spawn(in index: Int) {
        var bloot = WeightedList<Bloot>(Bloot.allCases(ignoreRh: ignoreRh).map { $0.weightedItem }).randomElement
        bloot.isDonor = false
        delegate.spawn(in: index, bloot: bloot)

        let time = Double.random(in: 0.0...2.0) * Double(bloot.receiversCount)
        timers[index] = Timer.scheduledTimer(withTimeInterval: time, repeats: false, block: { _ in self.spawn(in: index) })
    }

    func cancel() {
        timers.forEach { $0.invalidate() }
    }
}
