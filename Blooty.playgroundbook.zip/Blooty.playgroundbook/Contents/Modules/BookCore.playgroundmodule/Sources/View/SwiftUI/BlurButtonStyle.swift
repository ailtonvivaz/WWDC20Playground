//
//  BlurButtonStyle.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 13/05/20.
//

import SwiftUI

struct BlurButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .foregroundColor(.accentColor)
            .padding()
            .background(Blur(style: .extraLight))
            .cornerRadius(1000)
    }
}
