//
//  EpilogueCutsceneView.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 14/05/20.
//

import SwiftUI

public struct EpilogueCutsceneView: View {
    public init() {
        AudioManager.shared.play(sound: "loop.mp3", loop: true, volume: 0.005)
    }

    public var body: some View {
        ZStack {
            Color(Theme.Color.primary)
                .edgesIgnoringSafeArea(.all)
            GeometryReader { geo in
                VStack(spacing: 80) {
                    if self.isLandscape(for: geo) {
                        HStack(spacing: 80) {
                            VStack(spacing: 40) {
                                self.blootImage("aPos_blood_type")
                                self.blootImage("bPos_blood_type")
                                self.blootImage("abPos_blood_type")
                                self.blootImage("oPos_blood_type")
                            }.frame(width: 0.15 * geo.size.width)
                            self.message
                            VStack(spacing: 40) {
                                self.blootImage("aNeg_blood_type")
                                self.blootImage("bNeg_blood_type")
                                self.blootImage("abNeg_blood_type")
                                self.blootImage("oNeg_blood_type")
                            }.frame(width: 0.15 * geo.size.width)
                        }
                        .padding(.horizontal, 40)
                        .padding(.vertical, 80)
                    } else {
                        VStack(spacing: 80) {
                            HStack(spacing: 40) {
                                self.blootImage("aPos_blood_type")
                                self.blootImage("bPos_blood_type")
                                self.blootImage("abPos_blood_type")
                                self.blootImage("oPos_blood_type")
                            }.frame(height: 0.15 * geo.size.height)
                            self.message
                            HStack(spacing: 40) {
                                self.blootImage("aNeg_blood_type")
                                self.blootImage("bNeg_blood_type")
                                self.blootImage("abNeg_blood_type")
                                self.blootImage("oNeg_blood_type")
                            }.frame(height: 0.15 * geo.size.height)
                        }
                        .padding(.vertical)
                        .padding(.horizontal, 80)
                    }
                }
            }
        }
    }

    var message: some View {
        VStack(spacing: 30) {
            Text("EpilogueCongratulations")
                .font(.system(.largeTitle, design: .rounded))
                .fontWeight(.semibold)
            Text("EpilogueMessage")
                .font(.system(.title))
                .fontWeight(.light)
            (Text("EpilogueReferenceTitle")
                .font(.system(size: 20, weight: .light)) + Text("EpilogueReference")
                .font(.system(size: 20, weight: .light))
                .italic())
            VStack(spacing: 20) {
                Image(systemName: "heart.fill")
                    .font(.system(size: 50, weight: .light))
                    .padding(.top, 40)
                Text("EpilogueHowFind")
                    .font(.system(.title))
                    .fontWeight(.bold)
                Text("EpilogueLocaitionDonate")
                    .font(.system(size: 20, weight: .light))
                    .fontWeight(.light)
                    .lineLimit(nil)
            }
        }
        .multilineTextAlignment(.center)
    }

    func isLandscape(for geo: GeometryProxy) -> Bool {
        geo.size.width > geo.size.height
    }

    func blootImage(_ name: String) -> some View {
        Image(name)
            .resizable()
            .aspectRatio(2, contentMode: .fit)
    }
}
