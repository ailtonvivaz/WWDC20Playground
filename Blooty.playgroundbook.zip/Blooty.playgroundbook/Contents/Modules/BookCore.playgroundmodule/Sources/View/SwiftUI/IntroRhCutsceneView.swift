//
//  IntroRhCutsceneView.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 17/05/20.
//

import PlaygroundSupport
import SwiftUI

public struct IntroRhCutsceneView: View {
    public init() {
        AudioManager.shared.play(sound: "loop.mp3", loop: true, volume: 0.005)
    }

    @State var currentPage = 0
    var pagesCount: Int { 1 }
    var isFirstPage: Bool { currentPage == 0 }
    var isLastPage: Bool { currentPage == pagesCount - 1 }
    @State var isNext: Bool = true

    public var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(Theme.Color.primary)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    Spacer()

                    GeometryReader { geo in
                        VStack {
                            Text("Since then, things have changed. Blooties have evolved. Now they have a new energy")
                                .font(.system(size: 30, weight: .light))
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                            Image("rh_blood")
                            Text("Four new species arrised")
                                .font(.system(size: 30, weight: .light))
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)

                            if self.isLandscape(for: geo) {
                                HStack(spacing: 30) {
                                    self.blootImage("aPos_blood_type")
                                        .frame(width: 0.13 * geo.size.width)
                                    self.blootImage("bPos_blood_type")
                                        .frame(width: 0.13 * geo.size.width)
                                    self.blootImage("abPos_blood_type")
                                        .frame(width: 0.13 * geo.size.width)
                                    self.blootImage("oPos_blood_type")
                                        .frame(width: 0.13 * geo.size.width)
                                }
                            } else {
                                VStack(spacing: 30) {
                                    HStack(spacing: 30) {
                                        self.blootImage("aPos_blood_type")
                                            .frame(width: 0.25 * geo.size.width)
                                        self.blootImage("bPos_blood_type")
                                            .frame(width: 0.25 * geo.size.width)
                                    }
                                    HStack(spacing: 30) {
                                        self.blootImage("abPos_blood_type")
                                            .frame(width: 0.25 * geo.size.width)
                                        self.blootImage("oPos_blood_type")
                                            .frame(width: 0.25 * geo.size.width)
                                    }
                                }
                            }

                            Text("And your mission has evolved too. Have a look!")
                                .font(.system(size: 30, weight: .bold))
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .padding(.top, 40)
                                .frame(width: (self.isLandscape(for: geo) ? 0.3 : 0.5) * geo.size.width)
                        }
                        .frame(width: 0.5 * geo.size.width)
                        .foregroundColor(Color(Theme.Color.secondary))
                    }
                    Spacer()
                    Button(action: {
                        PlaygroundPage.current.navigateTo(page: .next)
                    }) {
                        Text("ContinueBook")
                            .font(.title)
                            .padding(.horizontal, 30)
                    }
                }
                .buttonStyle(BlurButtonStyle())
                .padding(50)
            }
        }
    }

    func isLandscape(for geo: GeometryProxy) -> Bool {
        geo.size.width > geo.size.height
    }

    func blootImage(_ name: String) -> some View {
        Image(name)
            .resizable()
            .aspectRatio(2, contentMode: .fit)
    }
}
