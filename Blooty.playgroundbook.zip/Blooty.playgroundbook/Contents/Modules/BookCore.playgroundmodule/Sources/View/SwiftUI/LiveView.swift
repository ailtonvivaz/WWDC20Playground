//
//  LiveView.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 12/05/20.
//

import SwiftUI

public struct LiveView: View {
    var text: String

    public init(text: String) {
        self.text = text
    }

    public var body: some View {
        ZStack {
            Color(Theme.Color.primary)
                .edgesIgnoringSafeArea(.all)
            HStack {
                Spacer()
                Text(text)
                    .font(.title)
                    .fontWeight(.light)
                    .foregroundColor(Color(Theme.Color.secondary))
                    .multilineTextAlignment(.trailing)
                    .padding(.horizontal, 100)
            }
        }
    }
}
