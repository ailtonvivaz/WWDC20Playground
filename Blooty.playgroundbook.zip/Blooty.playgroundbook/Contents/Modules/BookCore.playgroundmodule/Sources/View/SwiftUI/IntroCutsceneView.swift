//
//  IntroCutsceneView.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 13/05/20.
//

import PlaygroundSupport
import SwiftUI

public struct IntroCutsceneView: View {
    public init() {
        AudioManager.shared.play(sound: "loop.mp3", loop: true, volume: 0.005)
    }

    @State var currentPage = 0
    var pagesCount: Int { 4 }
    var isFirstPage: Bool { currentPage == 0 }
    var isLastPage: Bool { currentPage == pagesCount - 1 }
    @State var isNext: Bool = true

    private var defaultTransition: AnyTransition {
        AnyTransition.asymmetric(insertion: AnyTransition.opacity.animation(Animation.easeInOut(duration: 1.0).delay(0.2)), removal: AnyTransition.opacity.animation(.easeInOut(duration: 0.4)))
    }

    var page: some View {
        Group {
            if self.currentPage == 0 {
                self.page1
            } else if self.currentPage == 1 {
                self.page2
            } else if self.currentPage == 2 {
                self.page3
            } else if self.currentPage == 3 {
                self.page4
            }
        }
    }

    public var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(Theme.Color.primary)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    Spacer()
                    self.page
                    Spacer()

                    HStack {
                        Button(action: {
                            if !self.isFirstPage {
                                self.isNext = false
                                withAnimation(.easeInOut(duration: 1.0)) {
                                    self.currentPage -= 1
                                }
                            }
                        }) {
                            Image(systemName: "arrow.left")
                                .font(.title)
                                .padding(8)
                        }
                        .clipShape(Circle())
                        .opacity(self.isFirstPage ? 0.5 : 1.0)

                        Spacer()

                        if self.isLastPage {
                            Button(action: {
                                PlaygroundPage.current.navigateTo(page: .next)
                            }) {
                                Text("StartBook")
                                    .font(.title)
                                    .padding(.horizontal, 30)
                            }
                        } else {
                            Group {
                                Text("\(self.currentPage + 1) of \(self.pagesCount)")
                                    .foregroundColor(.white)
                                    .font(Font.title.monospacedDigit())
                                    .padding(.horizontal)

                                Spacer()

                                Button(action: {
                                    self.isNext = true
                                    withAnimation(.easeInOut(duration: 1.0)) {
                                        self.currentPage += 1
                                    }
                                }) {
                                    Image(systemName: "arrow.right")
                                        .font(.title)
                                        .padding(8)
                                }
                                .clipShape(Circle())
                            }
                            .transition(.opacity)
                        }
                    }.frame(width: (self.isLandscape(for: geo) ? 0.35 : 0.5) * geo.size.width)
                }
                .buttonStyle(BlurButtonStyle())
                .padding(50)
            }
        }
    }

    var page1: some View {
        GeometryReader { geo in
            VStack {
                Text("StartTwoEnergies")
                    .font(.system(size: 35, weight: .light))
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                HStack(spacing: 50) {
                    Image("a_blood")
                    Image("b_blood")
                }
                Image(systemName: "ellipsis")
                    .font(.system(size: 75, weight: .bold)).padding(40)
                Text("EnergiesClashed")
                    .font(.system(size: 35, weight: .light))
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                Text("Blooty")
                    .font(.system(size: 50, weight: .bold, design: .rounded))
                    .padding(30)
            }
            .frame(width: (self.isLandscape(for: geo) ? 0.5 : 0.8) * geo.size.width)
            .foregroundColor(Color(Theme.Color.secondary))
        }
        .transition(defaultTransition)
    }

    var page2: some View {
        GeometryReader { geo in
            VStack {
                Spacer()
                Text("EnergiesCombination")
                    .font(.system(size: 35, weight: .light))
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                Spacer()
                VStack(spacing: 50) {
                    HStack(spacing: 50) {
                        self.blootImage("a_blood_type")
                        self.blootImage("b_blood_type")
                    }
                    HStack(spacing: 50) {
                        self.blootImage("ab_blood_type")
                        self.blootImage("o_blood_type")
                    }
                }
                .frame(height: 250)
                .padding(.vertical)
                Spacer()
            }
            .frame(width: (self.isLandscape(for: geo) ? 0.5 : 0.8) * geo.size.width)
            .foregroundColor(Color(Theme.Color.secondary))
        }
        .transition(defaultTransition)
    }

    var page3: some View {
        GeometryReader { geo in
            VStack(spacing: 40) {
                Text("EnergieDischarged")
                    .font(.system(size: 30, weight: .light))
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)

                self.blootImage("a_blood_type_receiver")
                    .frame(width: 0.2 * geo.size.width)

                Text("YourMission")
                    .font(.system(size: 30, weight: .light))
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)

                self.blootImage("a_blood_type")
                    .frame(width: 0.2 * geo.size.width)
            }
            .frame(width: (self.isLandscape(for: geo) ? 0.5 : 0.8) * geo.size.width)
            .foregroundColor(Color(Theme.Color.secondary))
        }
        .transition(defaultTransition)
    }

    var page4: some View {
        GeometryReader { geo in
            VStack {
                HStack {
                    Group {
                        Image(systemName: "exclamationmark.triangle.fill")
                        Text("Important")
                    }
                    .font(.system(size: 30, weight: .bold))
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                }
                Group {
                    (Text("A Blooty").fontWeight(.light) + Text(" can't ").bold() + Text("beRecharged").fontWeight(.light))
                    Text("Example").fontWeight(.semibold)
                }
                .font(.system(size: 25))
                .fixedSize(horizontal: false, vertical: true)
                .multilineTextAlignment(.center)
                .padding(.top)

                self.blootImage("a_blood_type")
                    .frame(width: self.blootWidthPage4(for: geo))

                HStack(spacing: 40) {
                    VStack {
                        Text("Don't Recharge")
                            .font(.system(size: 18, weight: .semibold))
                            .lineLimit(1)
                        self.getBlootImage(bloot: "b_blood_type_donor", with: "heart.slash.fill", geo: geo)
                        self.getBlootImage(bloot: "ab_blood_type_donor", with: "heart.slash.fill", geo: geo)
                    }
                    .frame(width: self.blootWidthPage4(for: geo))

                    VStack {
                        Text("Recharge")
                            .font(.system(size: 18, weight: .semibold))
                            .lineLimit(1)
                        self.getBlootImage(bloot: "a_blood_type_donor", with: "heart.fill", geo: geo)
                        self.getBlootImage(bloot: "o_blood_type_donor", with: "heart.fill", geo: geo)
                    }
                    .frame(width: self.blootWidthPage4(for: geo))
                }
                .padding(.top)
            }
            .padding(20)
            .background(Color.black.opacity(0.2).cornerRadius(10))
            .padding(.vertical)
            .padding(.horizontal, self.isLandscape(for: geo) ? 40 : 0.0)
            .frame(width: (self.isLandscape(for: geo) ? 0.5 : 0.8) * geo.size.width)
            .foregroundColor(Color(Theme.Color.secondary))
        }
        .transition(defaultTransition)
    }
    
    func blootWidthPage4(for geo: GeometryProxy) -> CGFloat {
        (self.isLandscape(for: geo) ? 0.13 : 0.2) * geo.size.width
    }

    func isLandscape(for geo: GeometryProxy) -> Bool {
        geo.size.width > geo.size.height
    }

    func blootImage(_ name: String) -> some View {
        Image(name)
            .resizable()
            .aspectRatio(2, contentMode: .fit)
    }

    func getBlootImage(bloot: String, with image: String, geo: GeometryProxy) -> some View {
        ZStack {
            self.blootImage(bloot)
            Image(systemName: image)
                .font(.system(size: 0.11 * self.blootWidthPage4(for: geo)))
                .foregroundColor(Color(Theme.Color.secondary))
                .aspectRatio(1, contentMode: .fit)
                .padding(0.06 * self.blootWidthPage4(for: geo))
                .background(Color(Theme.Color.background))
                .clipShape(Circle())
                .offset(x: -0.45 * self.blootWidthPage4(for: geo), y: -0.2 * self.blootWidthPage4(for: geo))
        }
    }
}
