//
//  BlootCollectionViewCell.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 19/01/20.
//

import UIKit

class BlootCollectionViewCell: UICollectionViewCell {
    var blootView: BlootView!
    private var disableBlootView: BlootView!
    private var loadingView: LoadingView!
    
    private var countView: UIView!
    private var countLabel: UILabel!
    
    private var initialCenter: CGPoint = .zero
    
    private var timerLoading: Timer!
    
    private(set) var ready: Bool = true {
        didSet {
            blootView.alpha = ready ? 1 : 0
        }
    }
    
    private var isLast: Bool { showCounter && qty == 1 }
    private var hasBloot: Bool { qty > 0 }
    
    var bloot: Bloot! {
        didSet {
            if blootView == nil {
                disableBlootView = setupBlootView()
                blootView = setupBlootView()
            } else {
                disableBlootView.bloot = bloot
                blootView.bloot = bloot
            }
            bringSubviewToFront(loadingView)
            bringSubviewToFront(countView)
        }
    }
    
    var showCounter: Bool = false {
        didSet {
            countView.isHidden = !showCounter
        }
    }
    
    var qty: Int = -1 {
        didSet {
            self.countLabel.text = "\(qty)"
            self.disableBlootView.alpha = isLast || !hasBloot ? 0.1 : 1.0
            
            if oldValue == -1 {
                self.ready = hasBloot
            } else {
                UIView.animate(withDuration: 0.2) {
                    self.ready = self.hasBloot
                }
            }
            
            UIView.animate(withDuration: 1.0) {
                self.countView.transform = self.hasBloot ? .identity : CGAffineTransform(scaleX: 0, y: 0)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        countView.layer.cornerRadius = countView.frame.width / 2
    }
    
    private func setup() {
        loadingView = LoadingView()
        addSubview(loadingView)
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        loadingView.isHidden = true
        
        NSLayoutConstraint.activate([
            loadingView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.3),
            loadingView.heightAnchor.constraint(equalTo: loadingView.widthAnchor),
            loadingView.centerXAnchor.constraint(equalTo: centerXAnchor),
            loadingView.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
        
        countView = UIView()
        countView.backgroundColor = Theme.Color.background
        addSubview(countView)
        countView.translatesAutoresizingMaskIntoConstraints = false
        
        countLabel = UILabel()
        countLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        countLabel.textAlignment = .center
        countLabel.font = .systemFont(ofSize: 18, weight: .medium)
        countLabel.textColor = Theme.Color.secondary
        countLabel.sizeToFit()
        countView.addSubview(countLabel)
        
        NSLayoutConstraint.activate([
            countView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.25),
            countView.heightAnchor.constraint(equalTo: countView.widthAnchor),
            countView.centerXAnchor.constraint(equalTo: trailingAnchor),
            countView.topAnchor.constraint(equalTo: topAnchor, constant: -10),
        ])
        
        countView.isHidden = true
    }
    
    private func setupBlootView() -> BlootView {
        let blootView = BlootView(bloot: bloot)
        addSubview(blootView)
        
        blootView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            blootView.topAnchor.constraint(equalTo: topAnchor),
            blootView.leadingAnchor.constraint(equalTo: leadingAnchor),
            blootView.trailingAnchor.constraint(equalTo: trailingAnchor),
            blootView.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])
        
        return blootView
    }
    
    func startDrag(scale: CGFloat) {
        initialCenter = blootView.center
        
        UIView.animate(withDuration: 0.2) {
            self.blootView.transform = CGAffineTransform(scaleX: scale, y: scale)
        }
    }
    
    func drag(translation: CGPoint) {
        let newCenter = CGPoint(x: initialCenter.x + translation.x, y: initialCenter.y + translation.y)
        blootView.center = newCenter.offsetBy(dx: 0, dy: -80)
    }
    
    func resetPosition(unanimated: Bool = false, completion: @escaping () -> () = {}) {
        UIView.animate(withDuration: unanimated ? 0 : 0.1, animations: {
            self.blootView.center = self.initialCenter
            self.blootView.transform = .identity
        }) { _ in
            completion()
        }
    }
    
    func drop() {
        blootView.alpha = isLast ? 0 : 1
        if showCounter { qty -= 1 }
        resetPosition(unanimated: true)
    }
}
