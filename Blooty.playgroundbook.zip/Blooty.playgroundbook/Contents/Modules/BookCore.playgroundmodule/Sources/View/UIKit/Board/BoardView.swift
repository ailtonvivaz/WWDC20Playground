//
//  BoardView.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 11/05/20.
//

import UIKit

protocol BoardDelegate {
    func onLoss()
    func onWin()
}

class BoardView: UIView {
    private var layout: UICollectionViewFlowLayout!
    private var boardColletionView: UICollectionView!

    private(set) var bloots: Bloots = []
    var delegate: BoardDelegate?

    var qtyPerLine: Int = 3 {
        didSet {
            boardColletionView.reloadData()
        }
    }

    var lines: Int { Int(ceil(CGFloat(bloots.count) / CGFloat(qtyPerLine))) }
    var qtyLastLine: Int {
        let qty = bloots.count % qtyPerLine
        return qty == 0 ? qtyPerLine : qty
    }

    private let spacing: CGFloat = 0
    private let cellMargin: CGFloat = 50

    private var allHorizontalSpacing: CGFloat { CGFloat(qtyPerLine - 1) * spacing }
    private var cellWidth: CGFloat { ((boardColletionView.frame.width - allHorizontalSpacing) / CGFloat(qtyPerLine)) }
    private var cellHeight: CGFloat { max(0, ((cellWidth - cellMargin) / 2) + cellMargin) }
    private var contentHeight: CGFloat { cellHeight * CGFloat(lines) + spacing * CGFloat(lines - 1) }
    private var lastContentWidth: CGFloat { cellWidth * CGFloat(qtyLastLine) + spacing * CGFloat(qtyLastLine - 1) }
    private var verticalMargin: CGFloat {
        (boardColletionView.frame.height - contentHeight) / 2
    }

    private var horizontalMargin: CGFloat { (boardColletionView.frame.width - lastContentWidth) / 2 }

    var blootSize: CGSize { CGSize(width: max(0, cellWidth - cellMargin), height: max(0, cellHeight - cellMargin)) }

    private var allCells: [BoardViewCollectionViewCell] { boardColletionView.visibleCells.compactMap { $0 as? BoardViewCollectionViewCell } }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private func setup() {
        layout = UICollectionViewFlowLayout()
        boardColletionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        boardColletionView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(boardColletionView)

        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing
        layout.estimatedItemSize = .zero

        boardColletionView.showsVerticalScrollIndicator = false
        boardColletionView.backgroundColor = .clear

        boardColletionView.dataSource = self
        boardColletionView.delegate = self

        boardColletionView.registerFromNib(BoardViewCollectionViewCell.self)
    }

    func set(bloots: Bloots) {
        self.bloots = bloots
        boardColletionView.reloadData()
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        layout.prepare()
        layout.invalidateLayout()
    }

    func emphasize(for blootView: BlootView) {
        allCells.forEach { cell in
            cell.emphasized = cell.containsCenter(of: blootView)
        }
    }

    func drop(blootView: BlootView) -> Bool {
        var dropped = false
        allCells.forEach { cell in
            if cell.containsCenter(of: blootView) {
                dropped = cell.drop(blootView: blootView) {
                    if dropped {
                        self.bloots[cell.index].children = blootView.bloot
                        self.boardColletionView.reloadItems(at: [self.getBlootIndexPath(for: cell.index)])
                        self.checkBoard()
                    }
                }
                return
            }
        }
        return dropped
    }

    func checkBoard() {
        if bloots.allSatisfy({ $0.transfusionState == .success }) {
            delegate?.onWin()
            return
        }
        if bloots.contains(where: { $0.transfusionState == .fail }) {
            delegate?.onLoss()
            return
        }
    }
    
    func reset() {
        bloots.forEach { bloot in
            bloot.children = nil
        }
        boardColletionView.reloadData()
    }

    func getBlootIndex(for indexPath: IndexPath) -> Int {
        qtyPerLine * indexPath.section + indexPath.row
    }

    func getBlootIndexPath(for index: Int) -> IndexPath {
        IndexPath(row: index % qtyPerLine, section: index / qtyPerLine)
    }
}

// MARK: - UICollectionViewDataSource

extension BoardView: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int { lines }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == lines - 1 {
            return qtyLastLine
        }
        return qtyPerLine
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCellFromNib(BoardViewCollectionViewCell.self, for: indexPath) {
            let bloot = bloots[getBlootIndex(for: indexPath)]
            cell.index = getBlootIndex(for: indexPath)
            cell.bloot = bloot
            return cell
        }

        return UICollectionViewCell()
    }
}

//MARK: - UICollectionViewDelegateFlowLayout

extension BoardView: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        let top: CGFloat = section == 0 ? verticalMargin : 0
        let bottom: CGFloat = (section == lines - 1) ? verticalMargin : 0
        let horizontal: CGFloat = (section == lines - 1) && qtyLastLine < qtyPerLine ? horizontalMargin : 0
        return UIEdgeInsets(top: top, left: horizontal, bottom: bottom, right: horizontal)
    }
}
