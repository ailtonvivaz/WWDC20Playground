//
//  BlootBankView.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 19/01/20.
//

import UIKit

protocol BlootBankViewDelegate {
    func blootBankView(_ blootBankView: BlootBankView, scaleFor blootView: BlootView) -> CGFloat
    func blootBankView(_ blootBankView: BlootBankView, onDrag blootView: BlootView)
    func blootBankView(_ blootBankView: BlootBankView, hasDropPlaceFor blootView: BlootView) -> Bool
}

class BlootBankView: UIView {
    let layout: UICollectionViewFlowLayout!
    let collectionView: UICollectionView!

    var bloots: [Bloot]
    var ignoreRh: Bool
    var limited: Bool
    private var trashBloots: Bloots = []

    private var allBloots: [Bloot] { Bloot.allCases(ignoreRh: ignoreRh) }

    var delegate: BlootBankViewDelegate?

    var lines: Int = 1 {
        didSet {
            updateHeight()
        }
    }

    var qtyPerLine: Int { Int(ceil(Double(allBloots.count) / Double(lines))) }

    private let spacing: CGFloat = 20
    var allHorizontalSpacing: CGFloat { CGFloat(qtyPerLine - 1) * spacing }
    var cellWidth: CGFloat { (collectionView.frame.width - allHorizontalSpacing) / CGFloat(qtyPerLine) }
    var cellHeight: CGFloat { cellWidth / 2 }
    var collectionViewHeight: CGFloat { CGFloat(lines) * cellHeight + CGFloat(lines - 1) * spacing + 0.01 }

    lazy var heightConstraint: NSLayoutConstraint = collectionView.heightAnchor.constraint(equalToConstant: 0.01)

    var draggingBloot: BlootView?

    init(bloots: [Bloot], ignoreRh: Bool = true, limited: Bool = true) {
        self.bloots = bloots
        self.ignoreRh = ignoreRh
        self.limited = limited
        layout = UICollectionViewFlowLayout()

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        super.init(frame: .zero)

        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing

        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = .clear

        translatesAutoresizingMaskIntoConstraints = false
        heightConstraint.isActive = true

        setup()
    }

    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setup() {
        layer.cornerRadius = 20
        backgroundColor = UIColor.black.withAlphaComponent(0.2)

        addSubview(collectionView)
        collectionView.translatesAutoresizingMaskIntoConstraints = false

        collectionView.clipsToBounds = false

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: topAnchor, constant: spacing),
            collectionView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: spacing),
            collectionView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -spacing),
            collectionView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -spacing),
        ])

        collectionView.dataSource = self

        collectionView.register(BlootCollectionViewCell.self, forCellWithReuseIdentifier: "BlootCollectionViewCell")

        setNeedsLayout()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        updateHeight()
    }

    func updateHeight() {
        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        layout.prepare()
        layout.invalidateLayout()

        heightConstraint.constant = collectionViewHeight
    }

    @objc func panBloot(_ gestureRecognizer: UIPanGestureRecognizer) {
        guard let cell = gestureRecognizer.view as? BlootCollectionViewCell, cell.ready else { return }
        guard let blootView = cell.blootView else { return }
        guard draggingBloot == nil || draggingBloot == blootView else { return }

        let translation = gestureRecognizer.translation(in: blootView.superview)

        switch gestureRecognizer.state {
        case .began:
            draggingBloot = blootView
            collectionView.bringSubviewToFront(cell)

            if let scale = delegate?.blootBankView(self, scaleFor: blootView) {
                cell.startDrag(scale: scale)
            }
        case .changed:
            cell.drag(translation: translation)
            delegate?.blootBankView(self, onDrag: blootView)
        default:
            if delegate?.blootBankView(self, hasDropPlaceFor: blootView) != true {
                cell.resetPosition {
                    self.draggingBloot = nil
                }
            } else {
                cell.drop()
                draggingBloot = nil
            }
        }
    }

    func decrement(bloot: Bloot) {
        if let index = bloots.firstIndex(of: bloot) {
            bloots.remove(at: index)
            trashBloots.append(bloot)
        }
    }

    func reset() {
        bloots.append(contentsOf: trashBloots)
        trashBloots.removeAll()
        collectionView.reloadData()
    }
}

// MARK: - collection view datasource

extension BlootBankView: UICollectionViewDataSource {
    func collectionView(_: UICollectionView, numberOfItemsInSection _: Int) -> Int {
        allBloots.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BlootCollectionViewCell", for: indexPath) as? BlootCollectionViewCell {
            let bloot = allBloots[indexPath.row]
            cell.bloot = bloot
            cell.qty = bloots.filter { $0 == bloot }.count
            cell.showCounter = limited

            cell.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panBloot)))

            return cell
        }

        return UICollectionViewCell()
    }
}
