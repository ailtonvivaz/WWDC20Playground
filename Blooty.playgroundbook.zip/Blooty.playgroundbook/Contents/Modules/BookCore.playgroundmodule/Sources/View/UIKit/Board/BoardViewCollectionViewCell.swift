//
//  BoardViewCollectionViewCell.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 11/05/20.
//

import UIKit

class BoardViewCollectionViewCell: UICollectionViewCell {
    private var slotView: UIView!
    private var blootView: BlootView!
    private var donorBlootView: BlootView!
    private var okView: UIView!
    private var heartImageView: UIImageView!
    
    private let cellMargin: CGFloat = 25
    
    var bloot: Bloot! {
        didSet {
            setup()
        }
    }
    
    var index: Int = 0
    
    var donationOk: Bool {
        bloot.transfusionState == .success
    }
    
    var emphasized: Bool = false {
        didSet {
            UIView.animate(withDuration: 0.1) {
                self.contentView.alpha = self.emphasized ? 0.1 : 0.0
            }
        }
    }
    
    private func setup() {
        if let blootView = blootView {
            blootView.bloot = bloot
        } else {
            emphasized = false
            
            contentView.backgroundColor = .black
            contentView.layer.cornerRadius = 20
            
            blootView = BlootView(bloot: bloot!)
            addSubview(blootView)
            
            blootView.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                blootView.topAnchor.constraint(equalTo: topAnchor, constant: cellMargin),
                blootView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: cellMargin),
                blootView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -cellMargin),
                blootView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -cellMargin),
            ])
        }
        
        if bloot.isReceived {
            donorBlootView?.isHidden = false
            okView?.isHidden = false
            heartImageView?.isHidden = false
            
            setupDonorBlootView(animate: false)
            setOk(animate: false)
        } else {
            donorBlootView?.isHidden = true
            okView?.isHidden = true
            heartImageView?.isHidden = true
        }
    }
    
    private func setupDonorBlootView(animate: Bool = true, completion: @escaping () -> Void = {}) {
        if bloot.transfusionState == .none { return }
        var dBloot = bloot.children!
        if donationOk {
            dBloot = bloot.copy()
            dBloot.isDonor = true
            dBloot.children = nil
        }
        
        if let donorBlootView = donorBlootView {
            donorBlootView.isHidden = false
            donorBlootView.bloot = dBloot
        } else {
            donorBlootView = BlootView(bloot: dBloot)
            addSubview(donorBlootView)
            
            donorBlootView.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                donorBlootView.topAnchor.constraint(equalTo: blootView.topAnchor),
                donorBlootView.leadingAnchor.constraint(equalTo: blootView.leadingAnchor),
                donorBlootView.trailingAnchor.constraint(equalTo: blootView.trailingAnchor),
                donorBlootView.bottomAnchor.constraint(equalTo: blootView.bottomAnchor),
            ])
        }
        
        if dBloot == bloot.children || !animate {
            completion()
            return
        }
        
        donorBlootView.alpha = 0
        UIView.animate(withDuration: 1.0, animations: {
            self.donorBlootView.alpha = 1
        }) { _ in
            completion()
        }
    }
    
    private func setOk(animate: Bool = true, completion: @escaping () -> Void = {}) {
        if okView == nil {
            okView = UIView()
            okView.backgroundColor = Theme.Color.primary
            addSubview(okView)
            
            okView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                okView.topAnchor.constraint(equalTo: blootView.topAnchor),
                okView.leadingAnchor.constraint(equalTo: blootView.leadingAnchor),
                okView.trailingAnchor.constraint(equalTo: blootView.trailingAnchor),
                okView.bottomAnchor.constraint(equalTo: blootView.bottomAnchor),
            ])
            
            heartImageView = UIImageView(image: UIImage(systemName: donationOk ? "heart.fill" : "heart.slash.fill"))
            heartImageView.tintColor = Theme.Color.background
            heartImageView.contentMode = .scaleAspectFit
            addSubview(heartImageView)
            
            heartImageView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                heartImageView.heightAnchor.constraint(equalTo: okView.heightAnchor, multiplier: 0.5),
                heartImageView.widthAnchor.constraint(equalTo: okView.widthAnchor),
                heartImageView.centerXAnchor.constraint(equalTo: okView.centerXAnchor),
                heartImageView.centerYAnchor.constraint(equalTo: okView.centerYAnchor),
            ])
        } else {
            okView.isHidden = false
            heartImageView.isHidden = false
            heartImageView.image = UIImage(systemName: donationOk ? "heart.fill" : "heart.slash.fill")
        }
        
        if !animate {
            okView.alpha = 0.8
            heartImageView.alpha = 1
            heartImageView.transform = .identity
            completion()
            return
        }
        
        okView.alpha = 0
        heartImageView.alpha = 0
        heartImageView.transform = .init(scaleX: 0.25, y: 0.25)
        UIView.animate(withDuration: 1.0, animations: {
            self.okView.alpha = 0.8
            self.heartImageView.alpha = 1
            self.heartImageView.transform = .identity
        }) { _ in
            completion()
        }
    }
    
    func drop(blootView: BlootView, completion: @escaping () -> Void = {}) -> Bool {
        emphasized = false
        if bloot.children != nil { return false }
        
        let blootCenter = blootView.convertedCenter(to: self)
        let blootFrame = blootView.frame
        
        let blootView = blootView.copy() as! BlootView
        blootView.frame = blootFrame
        blootView.center = blootCenter
        addSubview(blootView)
        
        UIView.animate(withDuration: 0.3, animations: {
            blootView.frame = self.blootView.frame
        }) { _ in
            self.bloot.children = blootView.bloot
            self.setupDonorBlootView {
                blootView.removeFromSuperview()
                self.setOk(completion: completion)
            }
        }
        
        return true
    }
}
