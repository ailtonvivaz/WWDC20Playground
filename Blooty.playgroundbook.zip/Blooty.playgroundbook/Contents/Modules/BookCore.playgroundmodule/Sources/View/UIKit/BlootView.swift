//
//  BlootView.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 13/01/20.
//

import UIKit

public class BlootView: UIView, NSCopying {
    var bloot: Bloot {
        didSet {
            setup()
        }
    }

    let redCell = UIImageView()
    let bottomView = UIView()

    var antigensStackView: UIStackView!

    private var loaded = false

    init(bloot: Bloot) {
        self.bloot = bloot
        super.init(frame: .zero)
        setup()
    }

    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setup() {
        redCell.image = !bloot.isDonor ? .cellBlood : .cellAnti

        let antigensImages = bloot.allAntigens.map { bloot.antigens.contains($0) ? UIImage(named: "\($0)_\(bloot.isDonor ? "blood" : "anti")") : nil }

        if !loaded {
            redCell.translatesAutoresizingMaskIntoConstraints = false
            addSubview(redCell)

            NSLayoutConstraint.activate([
                redCell.topAnchor.constraint(equalTo: topAnchor, constant: 0),
                redCell.widthAnchor.constraint(equalTo: widthAnchor),
                redCell.centerXAnchor.constraint(equalTo: centerXAnchor),
                redCell.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 0.5),
            ])

            loaded = true
        }

        antigensStackView?.removeFromSuperview()
        antigensStackView = add(images: antigensImages, in: redCell)
    }

    private func add(images: [UIImage?], in view: UIView, alignment: UIStackView.Alignment = .center) -> UIStackView {
        let stackView = UIStackView()
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.topAnchor),
            stackView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.94),
            stackView.centerXAnchor.constraint(equalTo: centerXAnchor),
            stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])

        stackView.axis = .horizontal
        stackView.alignment = alignment
        stackView.distribution = .equalSpacing

        addEmptyView(to: stackView)
        for image in images {
            add(image: image, to: stackView)
        }
        addEmptyView(to: stackView)

        return stackView
    }

    private func addEmptyView(to stackView: UIStackView) {
        let view = UIView()
        stackView.addArrangedSubview(view)
        view.widthAnchor.constraint(equalTo: stackView.widthAnchor, multiplier: 0).isActive = true
    }

    private func add(image: UIImage?, to stackView: UIStackView) {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = image
        imageView.contentMode = .scaleAspectFit

        stackView.addArrangedSubview(imageView)

        imageView.widthAnchor.constraint(equalTo: stackView.widthAnchor, multiplier: 0.26).isActive = true
    }

    public func copy(with _: NSZone? = nil) -> Any { BlootView(bloot: bloot) }
}
