//
//  LoadingView.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 25/01/20.
//

import UIKit

public class LoadingView: UIView {
    private let shapeLayer = CAShapeLayer()
    private let color = UIColor.white.withAlphaComponent(0.5)

    var percent: Double = 0.0 {
        didSet {
            update()
        }
    }

    init() {
        super.init(frame: .zero)
        layer.addSublayer(shapeLayer)
        
        layer.borderColor = color.cgColor
    }

    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        update()

//        backgroundColor = .white
        layer.cornerRadius = frame.width / 2
        layer.borderWidth = 0.05 * frame.width
    }

    func update() {
        let radius = frame.size.width / 2
        let endAngle = CGFloat(percent * 2 * .pi)

        let center = CGPoint(x: radius, y: radius)
        
        let path = UIBezierPath()
        path.move(to: center)
        path.addLine(to: center.offsetBy(dx: radius, dy: 0))
        path.addArc(withCenter: center, radius: radius, startAngle: 0, endAngle: endAngle, clockwise: true)
        path.addLine(to: center)
        path.close()
    
        shapeLayer.path = path.cgPath
        shapeLayer.fillColor = color.cgColor
    }
}
