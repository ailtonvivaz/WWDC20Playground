//
//  LaneView.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 19/01/20.
//

import UIKit

class LaneView: UIView {
    var lane = Lane()
    private var blootViews: [BlootView] = []
    private var topConstraints: [NSLayoutConstraint] = []
    
    var firstBlootView: BlootView? { blootViews.first }
    
    var emphasized: Bool = false {
        didSet {
            backgroundColor = UIColor.white.withAlphaComponent(emphasized ? 0.2 : 0.1)
        }
    }
    
    init() {
        super.init(frame: .zero)
        
        defer {
            self.emphasized = false
        }
        
        clipsToBounds = true
    }
    
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func add(bloot: Bloot) {
        print("add", bloot.name)
        lane.add(bloot: bloot)
        let blootView = BlootView(bloot: bloot)
        addSubview(blootView)
        blootView.translatesAutoresizingMaskIntoConstraints = false
        
        let topConstraint = blootView.topAnchor.constraint(equalTo: topAnchor, constant: -0.5 * frame.width)
        NSLayoutConstraint.activate([
            topConstraint,
            blootView.widthAnchor.constraint(equalTo: widthAnchor),
            blootView.centerXAnchor.constraint(equalTo: centerXAnchor),
            blootView.heightAnchor.constraint(equalTo: blootView.widthAnchor, multiplier: 0.5),
        ])
        
        blootViews.append(blootView)
        topConstraints.append(topConstraint)
        updateTopConstraints()
    }
    
    func receive(bloot: Bloot, in frame: CGRect) {
        if let firstBlootView = self.firstBlootView {
            print("first", firstBlootView.bloot.name)
            let blootView = BlootView(bloot: bloot)
            addSubview(blootView)
            blootView.translatesAutoresizingMaskIntoConstraints = false
            
            let convertedFrame = firstBlootView.convert(frame, from: superview!)
            
            let topAnchor = blootView.topAnchor.constraint(equalTo: firstBlootView.topAnchor, constant: convertedFrame.origin.y)
            let leadingAnchor = blootView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: frame.origin.x)
            
            NSLayoutConstraint.activate([
                topAnchor,
                leadingAnchor,
                blootView.widthAnchor.constraint(equalTo: widthAnchor),
                blootView.heightAnchor.constraint(equalTo: blootView.widthAnchor, multiplier: 0.5),
            ])
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
                UIView.animate(withDuration: 0.2, animations: {
                    leadingAnchor.constant = 0
                    self.layoutIfNeeded()
                }) { _ in
                    self.bringSubviewToFront(firstBlootView)
                    
                    let receive = self.lane.receive(bloot: bloot)
                    UIView.animate(withDuration: 1.0, animations: {
                        topAnchor.constant = receive ? 0 : blootView.frame.height
                        self.layoutIfNeeded()
                    }) { _ in
                        if receive {
                            UIView.animate(withDuration: 0.2, animations: {
                                self.firstBlootView?.alpha = 0
                                blootView.alpha = 0
                            }) { _ in
                                blootView.removeFromSuperview()
                                firstBlootView.removeFromSuperview()
                                self.lane.removeFirst()
                                self.blootViews.removeFirst()
                                self.topConstraints.removeFirst()
                                self.updateTopConstraints()
                            }
                        } else {
                            blootView.removeFromSuperview()
                        }
                    }
                }
            }
        }
    }
    
    public override func layoutSubviews() {
        super.layoutSubviews()
        updateTopConstraints()
    }
    
    func updateTopConstraints() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            UIView.animate(withDuration: 1) {
                for i in 0..<self.topConstraints.count {
                    let pos = self.topConstraints.count - 1 - i
                    let topConstraint = self.topConstraints[i]
                    topConstraint.constant = (CGFloat(pos) * (0.5 * self.frame.width + 10.0)) + 10.0
                }
                self.layoutIfNeeded()
            }
        }
    }
}
