//
//  BarButtonView.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 09/05/20.
//

import PlaygroundSupport
import UIKit

class BarButtonView: UIButton {
    private var blurView = UIVisualEffectView(effect: nil)
    
    private let spacing = CGFloat(20.0)
    private let buttonSize = CGSize(width: 44, height: 44)
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        translatesAutoresizingMaskIntoConstraints = false
        
        blurView.effect = UIBlurEffect(style: .light)
        if #available(iOS 13.0, *) {
            blurView.effect = UIBlurEffect(style: .systemThickMaterial)
        }
        
        tintColor = .link
        setTitleColor(.link, for: .normal)
        
        updateInsets()
        
        blurView.translatesAutoresizingMaskIntoConstraints = false
        blurView.clipsToBounds = true
        blurView.frame = bounds
        blurView.isUserInteractionEnabled = false
        addSubview(blurView)
        
        let highPriorityWidth = widthAnchor.constraint(equalToConstant: buttonSize.width)
        let highPriorityHeight = heightAnchor.constraint(equalToConstant: buttonSize.height)
        
        highPriorityWidth.priority = .defaultHigh
        highPriorityHeight.priority = .defaultHigh
        
        NSLayoutConstraint.activate([
            highPriorityHeight,
            blurView.widthAnchor.constraint(equalTo: widthAnchor),
            blurView.heightAnchor.constraint(equalTo: heightAnchor)
        ])
    }
    
    private func updateInsets() {
        contentEdgeInsets = UIEdgeInsets.zero
        imageEdgeInsets = UIEdgeInsets.zero
        titleEdgeInsets = UIEdgeInsets.zero
        
        if let imageView = imageView, let _ = imageView.image {
            var spacing = (frame.height - imageView.frame.width) / 2
            contentEdgeInsets = UIEdgeInsets(top: 11, left: spacing, bottom: 11, right: spacing)
        }
        
        if let title = titleLabel?.text, !title.isEmpty {
            contentEdgeInsets = UIEdgeInsets(top: 11, left: spacing, bottom: 11, right: spacing)
            titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: -spacing / 2)
        }
    }
    
    open override func setTitle(_ title: String?, for state: UIControl.State) {
        super.setTitle(title, for: state)
        updateInsets()
    }
    
    open override func setImage(_ image: UIImage?, for state: UIControl.State) {
        super.setImage(image, for: state)
        updateInsets()
    }
    
    open override func layoutSubviews() {
        super.layoutSubviews()
        blurView.layer.cornerRadius = bounds.size.height / 2.0
        sendSubviewToBack(blurView)
    }
}
