//
//  DataStore.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 16/05/20.
//

import Foundation
import PlaygroundSupport

public class DataStore {
    static public var shared = DataStore()
    
    public var blooty: Blooty? {
        get {
            if case let .string(value) = PlaygroundKeyValueStore.current["blooty"] {
                return Blooty(rawValue: value)
            }
            return nil
        }
        set {
            PlaygroundKeyValueStore.current["blooty"] = (newValue == nil) ? .string("") : .string(newValue!.rawValue)
        }
    }

    private init() {}
}
