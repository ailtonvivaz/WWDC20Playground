//
//  BloodType.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 13/01/20.
//

import Foundation

public typealias Bloots = [Bloot]

enum BlootTransfusion {
    case none, success, fail
}

public class Bloot {
    let name: String
    let antigens: Antigens
    let ignoreRh: Bool
    var isDonor: Bool = true
    var children: Bloot?
    var isReceived: Bool { children != nil }
    var transfusionState: BlootTransfusion {
        guard let children = children else { return .none }
        if isDonor {
            return isDonor(for: children) ? .success : .fail
        } else {
            return isReceiver(of: children) ? .success : .fail
        }
    }

    public static var a: Bloot { Bloot([.a], name: "A", ignoreRh: true) }
    public static var b: Bloot { Bloot([.b], name: "B", ignoreRh: true) }
    public static var ab: Bloot { Bloot([.a, .b], name: "AB", ignoreRh: true) }
    public static var o: Bloot { Bloot([], name: "O", ignoreRh: true) }

    public static var aPos: Bloot { Bloot([.a, .rh], name: "A+") }
    public static var bPos: Bloot { Bloot([.b, .rh], name: "B+") }
    public static var abPos: Bloot { Bloot([.a, .b, .rh], name: "AB+") }
    public static var oPos: Bloot { Bloot([.rh], name: "O+") }
    public static var aNeg: Bloot { Bloot([.a], name: "A-") }
    public static var bNeg: Bloot { Bloot([.b], name: "B-") }
    public static var abNeg: Bloot { Bloot([.a, .b], name: "AB-") }
    public static var oNeg: Bloot { Bloot([], name: "O-") }

    var antibodies: Antigens { allAntigens.filter { !antigens.contains($0) } }

    var allAntigens: Antigens { Self.allAntigens(ignoreRh: ignoreRh) }

    static func allAntigens(ignoreRh: Bool = false) -> Antigens {
        if ignoreRh {
            return Antigen.allCases.filter { $0 != .rh }
        }
        return Antigen.allCases
    }

    public static func allCases(ignoreRh: Bool = false) -> [Bloot] {
        if ignoreRh {
            return [Bloot]([.a, .b, .ab, .o])
        } else {
            return [Bloot]([.aPos, .bPos, .abPos, .oPos, .aNeg, .bNeg, .abNeg, .oNeg])
        }
    }

    public static func random(ignoreRh: Bool = false) -> Bloot {
        allCases(ignoreRh: ignoreRh).randomElement()!
    }

    public var donors: Bloots {
        Bloot.allCases(ignoreRh: ignoreRh).filter { $0.isDonor(for: self) }
    }

    public var receivers: Bloots {
        Bloot.allCases(ignoreRh: ignoreRh).filter { $0.isReceiver(of: self) }
    }

    var donorsCount: Int { 2 ^^ antigens.count }
    var receiversCount: Int {
        let qtyAntibodies = Self.allAntigens(ignoreRh: ignoreRh).count - antigens.count
        return 2 ^^ qtyAntibodies
    }

    init(_ antigens: Antigens, name: String, ignoreRh: Bool = false) {
        self.antigens = antigens
        self.name = name
        self.ignoreRh = ignoreRh
    }

    func isDonor(for bloot: Bloot) -> Bool {
        let isDonor = bloot.antibodies.intersection(from: antigens).count == 0

        print("\(name) isDonor for \(bloot.name) = \(isDonor)")

        return isDonor
    }

    func isReceiver(of bloot: Bloot) -> Bool {
        bloot.isDonor(for: self)
    }

    func with(donor: Bool) -> Bloot {
        let bloot = self
        bloot.isDonor = donor
        return bloot
    }
    
    func copy() -> Bloot {
        let bloot = Bloot(antigens, name: name, ignoreRh: ignoreRh)
        bloot.isDonor = isDonor
        bloot.children = children
        return bloot
    }
}

extension Bloot: Equatable {
    public static func ==(lhs: Bloot, rhs: Bloot) -> Bool {
        lhs.antigens == rhs.antigens && lhs.ignoreRh == rhs.ignoreRh
    }
}
