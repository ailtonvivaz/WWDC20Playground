//
//  Antigen.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 18/01/20.
//

import Foundation

public typealias Antigens = [Antigen]

public enum Antigen: String, CaseIterable {
    case a
    case b
    case rh
}
