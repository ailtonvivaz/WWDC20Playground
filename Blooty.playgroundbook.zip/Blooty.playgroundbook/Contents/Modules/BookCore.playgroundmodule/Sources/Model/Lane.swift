//
//  Lane.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 25/01/20.
//

import Foundation

struct Lane {
    private(set) var bloots: [Bloot] = []

    var firstBloot: Bloot? { bloots.first }

    mutating func add(bloot: Bloot) {
        self.bloots.append(bloot)
    }
    
    mutating func removeFirst() {
        self.bloots.removeFirst()
    }

    func receive(bloot: Bloot) -> Bool {
        if let firstBloot = firstBloot {
            return bloot.isDonor(for: firstBloot)
        }
        return false
    }
}
