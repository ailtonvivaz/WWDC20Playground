//
//  Blooty.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 15/05/20.
//

import Foundation

typealias Blooties = [Blooty]

public enum Blooty: String {
    case a, b, ab, o
    case aPos, bPos, abPos, oPos, aNeg, bNeg, abNeg, oNeg
    case random

    public func getBloot(ignoreRh: Bool) -> Bloot {
        switch self {
        case .a:
            return .a
        case .b:
            return .b
        case .ab:
            return .ab
        case .o:
            return .o
        case .aPos:
            return .aPos
        case .bPos:
            return .bPos
        case .abPos:
            return .abPos
        case .oPos:
            return .oPos
        case .aNeg:
            return .aNeg
        case .bNeg:
            return .bNeg
        case .abNeg:
            return .abNeg
        case .oNeg:
            return .oNeg
        case .random:
            return .random(ignoreRh: ignoreRh)
        }
    }
}
