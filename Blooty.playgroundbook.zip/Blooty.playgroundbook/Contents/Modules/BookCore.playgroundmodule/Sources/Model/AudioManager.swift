//
//  AudioManager.swift
//  BookCore
//
//  Created by Ailton Vieira Pinto Filho on 18/05/20.
//

import AVFoundation

class AudioManager {
    static var shared = AudioManager()
    private var player = AVAudioPlayer()

    private init() {}

    func play(sound: String, loop: Bool = false, volume: Float = 0.1) {
        guard let path = Bundle.main.path(forResource: sound, ofType: nil) else { return }

        let url = URL(fileURLWithPath: path)

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)

            player = try AVAudioPlayer(contentsOf: url)
            player.volume = volume
            player.numberOfLoops = loop ? -1 : 0

            player.play()

        } catch {
            print(error.localizedDescription)
        }
    }
    
    func stop() {
        player.stop()
    }
}
