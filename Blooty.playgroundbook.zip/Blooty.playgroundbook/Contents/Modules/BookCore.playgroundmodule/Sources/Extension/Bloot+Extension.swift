//
//  Bloot+Extension.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 06/02/20.
//

import Foundation

extension Bloot {
    var weightedItem: WeightedItem<Bloot> { WeightedItem(item: self, weight: Double(self.donorsCount)) }
}
