//
//  UICollectionView+Extension.swift
//  LiveViewTestApp
//
//  Created by Ailton Vieira Pinto Filho on 11/05/20.
//

import UIKit

extension UICollectionView {
    func registerFromNib<T: UICollectionViewCell>(_ clazz: T.Type) {
        register(clazz, forCellWithReuseIdentifier: "\(clazz)")
    }

    func dequeueReusableCellFromNib<T: UICollectionViewCell>(_ clazz: T.Type, for indexPath: IndexPath) -> T? {
        return dequeueReusableCell(withReuseIdentifier: "\(clazz)", for: indexPath) as? T
    }
}
