//
//  CGPoint+Extension.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 25/01/20.
//

import UIKit

public extension CGPoint {
  func offsetBy(dx: CGFloat, dy: CGFloat) -> CGPoint {
    return CGPoint(x: x + dx, y: y + dy)
  }
}
