//
//  UIView+Extension.swift
//  Book_Sources
//
//  Created by Ailton Vieira Pinto Filho on 25/01/20.
//

import UIKit

public extension UIView {
    func contains(_ view: UIView) -> Bool {
        return self.frame.contains(view.convertedFrame(to: self.superview!))
    }

    func containsCenter(of view: UIView) -> Bool {
        self.frame.contains(view.convertedCenter(to: self.superview!))
    }

    func convertedCenter(to view: UIView) -> CGPoint {
        superview!.convert(self.center, to: view)
    }

    func convertedFrame(to view: UIView) -> CGRect {
        superview!.convert(self.frame, to: view)
    }
}
